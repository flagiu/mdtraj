# This is an example of how QVECTORS for S(q) can be generated

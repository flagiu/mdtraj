#!/bin/bash
rm *.xyz *.dat *.ave *.traj *.xxx *.png *.pdf log

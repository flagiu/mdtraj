#!/bin/bash
rm -r __pycache__ *.out *.data *.dat *.xyz *.traj *.ave *.png *.pdf log* *.xxx *.box ed*.txt

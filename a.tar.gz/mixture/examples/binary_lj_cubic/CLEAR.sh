#!/bin/bash
gzip dump.lammpstrj
rm *.xyz *.dat *.ave *.traj *.xxx *.png *.pdf log out.lmp log.lammps *.local_ave

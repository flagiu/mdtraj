#!/bin/bash
rm -r __pycache__
rm *.out *.data *.dat *.xyz *.traj *.ave *.png *.pdf
rm log* *.xxx *.box ed*.txt *.local_ave *.indexes

#!/bin/bash
gzip trajectory
rm *.xyz *.dat *.ave *.traj *.xxx *.png *.pdf log* *.txt *.local_ave *.indexes

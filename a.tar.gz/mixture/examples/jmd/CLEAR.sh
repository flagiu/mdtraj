#!/bin/bash
rm -r traj.jmd *.out *.dat *.xyz *.traj *.ave *.png *.pdf log* *.xxx *.indexes ed_q*.txt *.local_ave 2>> /dev/null

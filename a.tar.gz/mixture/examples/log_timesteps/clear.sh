rm schedule.times out.lmp err.lmp log.lammps dump.lammpstrj forces.dump energy.dump restart{1,2} restart_*

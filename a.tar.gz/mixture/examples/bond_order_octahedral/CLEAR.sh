rm *.traj *.xxx *.ave *.dat *.png *.pdf log ed_q*txt *.xyz log*
